# 9×4 战棋对战

这是一个可直接上传到 GitHub Pages 的网页版战棋项目。

## 文件结构

- `index.html`：入口页面
- `style.css`：样式
- `heroes.js`：英雄数据与技能描述
- `game.js`：游戏引擎与交互逻辑

## 上传方式

把这 4 个文件放在仓库根目录：

```text
index.html
style.css
heroes.js
game.js
```

然后到 GitHub 仓库：

1. `Settings`
2. `Pages`
3. `Deploy from branch`
4. 选择 `main / root`
5. 保存

等一会儿就会生成网址。

## 玩法

- 先进入阵容选择
- 蓝方先选 3 个英雄，再轮到红方选 3 个英雄
- 点击“开始战斗”
- 点击己方英雄查看完整信息
- 点击空格移动，点击敌人攻击
- 下方会显示当前英雄的技能按钮与说明
